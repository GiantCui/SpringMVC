create definer = root@localhost trigger radarUpdate
    before update
    on radar
    for each row
begin
	declare str text character set utf8;
    declare id text character set utf8;
    declare sign boolean;
    set sign = false;
    set id = uuid();
    -- ip地址更新 --
    if (new.radarIP != old.radarIP) then
		set sign = true;
		set str = concat(str, "IP地址更新；");
	end if;
	-- 异物状态更新 --
    if (new.foreignMatter != old.foreignMatter) then
		if (old.foreignMatter != true) then
			set str = "出现异物";
		else
			set str = "异物消除";
		end if;
     end if;
     -- 工作状态更新 --
    if (new.workState != old.workState) then
		if (old.workState != true) then
			set str = "进入旁路";
		else
			set str = "开始工作";
		end if;
     end if;
     insert into `RadarLog`(`radarID`, `log`)
	 values(new.sirialnum, str);
     select logNum into id from RadarLog order by logNum DESC limit 1;
     set new.lastlog = id;
end;

