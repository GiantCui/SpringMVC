create definer = root@localhost trigger radarUpdate
    before update
    on radar
    for each row
begin
	declare str text character set utf8;
    declare id text character set utf8;
    set id = uuid();
	if (new.workState != old.workState) then  
		set str = '工作状态改变';
		insert into RadarLog 
		(`logNum`, `radarID`, `log`)  
		values(id, new.radarID, str);
        set new.lastlog = id;
    end if;
end;

