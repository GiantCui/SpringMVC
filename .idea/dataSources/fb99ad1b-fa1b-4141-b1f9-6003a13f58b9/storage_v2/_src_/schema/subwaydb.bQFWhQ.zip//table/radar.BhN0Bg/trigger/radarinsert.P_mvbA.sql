create definer = root@localhost trigger radarInsert
    before insert
    on radar
    for each row
begin
	declare str text character set utf8;
    declare id bigint;
	set str = '新增雷达';
	insert into RadarLog 
	(`radarID`, `log`, `progress`)  
	values(new.sirialNum, str, true);
    select logNum into id from RadarLog order by logNum DESC limit 1;
    set new.lastlog = id;
end;

