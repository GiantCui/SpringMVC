create definer = root@localhost trigger radarInsert
    before insert
    on radar
    for each row
begin
	declare str text character set utf8;
    declare id varchar(36) character set utf8;
	set str = '新增雷达';
    set id = uuid();
	insert into RadarLog 
	(`logNum`, `radarID`, `log`, `endTime`, `identify`, `progress`)  
	values(id, new.radarID, str, current_timestamp(), 5, true);
    set new.lastlog = id;
end;

