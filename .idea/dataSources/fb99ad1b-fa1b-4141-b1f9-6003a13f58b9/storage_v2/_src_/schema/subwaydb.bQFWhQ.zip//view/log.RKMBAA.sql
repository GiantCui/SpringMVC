create definer = root@localhost view log as
select `a`.`radarID`       AS `radarID`,
       `a`.`radarIP`       AS `radarIP`,
       `a`.`port`          AS `port`,
       `a`.`sirialNum`     AS `sirialNum`,
       `a`.`workState`     AS `workState`,
       `a`.`foreignMatter` AS `foreignMatter`,
       `a`.`safetyDoor`    AS `safetyDoor`,
       `a`.`radarError`    AS `radarError`,
       `a`.`lastlog`       AS `lastlog`,
       `a`.`comment`       AS `comment`,
       `b`.`logNum`        AS `logNum`,
       `b`.`startTime`     AS `startTime`,
       `b`.`endTime`       AS `endTime`,
       `b`.`log`           AS `log`
from (`subwaydb`.`radar` `a`
         join `subwaydb`.`radarlog` `b` on ((`a`.`radarID` = `b`.`radarID`)));

