create definer = root@localhost view log as
select `a`.`radarID`       AS `radarID`,
       `a`.`radarIP`       AS `radarIP`,
       `a`.`port`          AS `port`,
       `a`.`sirialNum`     AS `sirialNum`,
       `a`.`workState`     AS `workState`,
       `a`.`foreignMatter` AS `foreignMatter`,
       `a`.`safetyDoor`    AS `safetyDoor`,
       `a`.`radarError`    AS `radarError`,
       `a`.`lastlog`       AS `lastlog`,
       `a`.`comment`       AS `comment`,
       `a`.`doorstate`     AS `doorstate`,
       `a`.`ringPst`       AS `ringPst`,
       `a`.`warnRng`       AS `warnRng`,
       `a`.`doorSize`      AS `doorSize`,
       `a`.`gap`           AS `gap`,
       `b`.`logNum`        AS `logNum`,
       `b`.`time`          AS `time`,
       `b`.`log`           AS `log`
from (`subwaydb`.`radar` `a`
         join `subwaydb`.`radarlog` `b` on ((`a`.`sirialNum` = `b`.`radarID`)));

